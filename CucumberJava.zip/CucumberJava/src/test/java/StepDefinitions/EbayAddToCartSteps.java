package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import Pages.EbayPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EbayAddToCartSteps {

	EbayPage ebayPage = new EbayPage();

	@Given("User opens browser and navigates to ebay.com")
	public void user_opens_browser_and_navigates_to_ebay_com() {
		ebayPage.openEbaySite();
	}

	@Then("ebay.com page should get opened")
	public void ebay_com_page_should_get_opened() {
		Assert.assertTrue(ebayPage.verifyEbayLogoIsDisplayed());
	}

	@When("User search for {string}")
	public void user_search_for(String searchText) {
		ebayPage.enterTextInSearchBox(searchText);

	}

	@When("User clicks on the first book in the list")
	public void user_clicks_on_the_first_book_in_the_list() {
		ebayPage.clickOnFirstBookInSearchResult();
	}

	@When("In the item listing page, user clicks on {string}")
	public void in_the_item_listing_page_user_clicks_on(String string) {
		ebayPage.clickOnAddToCartButton();
	}

	@Then("Verify the cart has been updated and displays the number of items in the cart as {string}")
	public void verify_the_cart_has_been_updated_and_displays_the_number_of_items_in_the_cart_as(
			String expectedNoOfItems) {
		String actualNoOfItems = ebayPage.verifyCartNoOfItems();
		Assert.assertEquals(expectedNoOfItems, actualNoOfItems);
	}
	
	

}
