package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.junit.Assert.assertEquals;

public class CurrentPriceAPISteps {
	Response response;

	JsonPath jsonPathEvaluator;

	@Given("User sends the GET request for {string}")
	public void user_sends_the_get_request_for(String uri) {
		response = given().auth().none().get(uri);
	}

	@Then("Verify the response for BPI contains required values for GBP USD and EUR")
	public void verify_the_response_contains_bpi_required_values() {
		jsonPathEvaluator = response.jsonPath();
		LinkedHashMap<String, String> bpiSet = jsonPathEvaluator.get("bpi");
		Set<String> bpiKeysSet = bpiSet.keySet();
		assertThat(bpiKeysSet, hasItems("USD", "GBP", "EUR"));

	}

	@Then("Verify the description for GBP currency is {string}")
	public void verify_the_description_for_gbp_currency_is(String expectedDescriptionValue) {
		String actualDescriptionValue = jsonPathEvaluator.get("bpi.GBP.description");
		assertEquals(expectedDescriptionValue, actualDescriptionValue);
	}
}
