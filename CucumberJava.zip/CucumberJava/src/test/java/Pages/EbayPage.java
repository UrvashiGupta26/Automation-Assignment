package Pages;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EbayPage {

	WebDriver driver;

	By ebayLogo = By.id("gh-la");
	By searchBox = By.xpath("//input[@placeholder='Search for anything']");
	By searchButton = By.xpath("//input[@id='gh-btn']");
	By resultsHeading = By.xpath("//h1[contains(@class,'srp-controls__count-heading')]");

	By firstBookInList = By.xpath("(//div[@class='s-item__title'])[3]");
	By addToCartButton = By.xpath("//span[text()='Add to cart']");
	By cartTopIcon = By.xpath("//i[@id='gh-cart-n']");

	public void openEbaySite() {
		driver = new EdgeDriver();
		driver.get("https://ebay.com/");
		driver.manage().window().maximize();
	}

	public boolean verifyEbayLogoIsDisplayed() {
		return driver.findElement(ebayLogo).isDisplayed();
	}

	public void enterTextInSearchBox(String searchText) {
		driver.findElement(searchBox).sendKeys(searchText);
		driver.findElement(searchButton).click();
	}

	public void clickOnFirstBookInSearchResult() {
		WebElement firstInListElement = driver.findElement(firstBookInList);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.visibilityOfElementLocated(firstBookInList));
		firstInListElement.click();
	}

	public void clickOnAddToCartButton() {

		Set<String> windowHandles = driver.getWindowHandles();
		Iterator<String> it = windowHandles.iterator();
		String parentWindowId = it.next();
		String childWindowId = it.next();
		driver.switchTo().window(childWindowId);
		WebElement addToCartElement = driver.findElement(addToCartButton);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartButton));
		addToCartElement.click();
	}

	public String verifyCartNoOfItems() {
		String actualNoOfItems = driver.findElement(cartTopIcon).getText();
		driver.quit();
		return actualNoOfItems;
	}

}
